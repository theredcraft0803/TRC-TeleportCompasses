package de.trc.TRC_TeleportCompasses;

import de.trc.TRC_TeleportCompasses.Constants;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public final class TRC_TeleportCompasses extends JavaPlugin {

    @Override
    public void onEnable() {
        Constants.LOGGER.info("TRC Teleport Compasses aktiviert");

        Constants.IS_TP_COMPASS = new NamespacedKey(this, "is_tp_compass");

        new Crafting(this).registerRecipes(); // <-- das einzige was neu dazukommt
    }

    @Override
    public void onDisable() {
        Constants.LOGGER.info("TRC Teleport Compasses deaktiviert");
    }
}
