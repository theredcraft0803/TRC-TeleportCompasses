package de.trc.TRC_TeleportCompasses;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CompassMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public class CraftListener implements Listener {

    private final JavaPlugin plugin;
    private final NamespacedKey recipeKey;

    public CraftListener(JavaPlugin plugin, NamespacedKey recipeKey) {
        this.plugin = plugin;
        this.recipeKey = recipeKey;
    }

    @EventHandler
    public void onPrepareItemCraft(PrepareItemCraftEvent event) {
        // Only handle our recipe
        if (event.getRecipe() == null) return;
        if (!(event.getRecipe() instanceof org.bukkit.inventory.ShapedRecipe shaped)) return;
        if (!shaped.getKey().equals(recipeKey)) return;

        CraftingInventory inv = event.getInventory();
        ItemStack compassIngredient = findCompassIngredient(inv);

        // --- Validation ---
        if (compassIngredient == null) {
            inv.setResult(null);
            return;
        }

        if (!(compassIngredient.getItemMeta() instanceof CompassMeta compassMeta)) {
            inv.setResult(null);
            return;
        }

        // Must have lodestone data
        if (!compassMeta.hasLodestone()) {
            inv.setResult(null);
            return;
        }

        // Must NOT already be a TP Compass
        PersistentDataContainer pdc = compassMeta.getPersistentDataContainer();
        if (pdc.has(Constants.IS_TP_COMPASS, PersistentDataType.BYTE)) {
            inv.setResult(null);
            return;
        }

        // --- Build the result ---
        Location lodestone        = compassMeta.getLodestone();
        boolean lodestoneTracked  = compassMeta.isLodestoneTracked();

        ItemStack result = new ItemStack(Material.COMPASS);
        CompassMeta resultMeta = (CompassMeta) result.getItemMeta();

        // Copy lodestone data
        resultMeta.setLodestone(lodestone);
        resultMeta.setLodestoneTracked(lodestoneTracked);

        // Display name & rarity
        resultMeta.displayName(
                net.kyori.adventure.text.Component.text("Teleport Compass")
                        .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)
                        .color(net.kyori.adventure.text.format.NamedTextColor.LIGHT_PURPLE)
        );
        resultMeta.setRarity(org.bukkit.inventory.ItemRarity.RARE);

        // Mark as TP Compass
        resultMeta.getPersistentDataContainer()
                .set(Constants.IS_TP_COMPASS, PersistentDataType.BYTE, (byte) 1);

        result.setItemMeta(resultMeta);
        inv.setResult(result);
    }

    /** Searches all crafting grid slots for the COMPASS ingredient. */
    private ItemStack findCompassIngredient(CraftingInventory inv) {
        for (ItemStack item : inv.getMatrix()) {
            if (item != null && item.getType() == Material.COMPASS) {
                return item;
            }
        }
        return null;
    }
}
