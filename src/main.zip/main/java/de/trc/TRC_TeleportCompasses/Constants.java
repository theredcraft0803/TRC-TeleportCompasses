package de.trc.TRC_TeleportCompasses;

import org.bukkit.NamespacedKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Constants {
    public static Logger LOGGER = LoggerFactory.getLogger("TRC Teleport Compasses");
    public static NamespacedKey IS_TP_COMPASS;
}
