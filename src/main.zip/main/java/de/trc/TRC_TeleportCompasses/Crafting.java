package de.trc.TRC_TeleportCompasses;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.CompassMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public class Crafting {

    private final JavaPlugin plugin;

    public Crafting(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void registerRecipes() {
        registerTpCompassRecipe();
    }

    private void registerTpCompassRecipe() {
        // Result item: a plain compass as base — the actual output is built dynamically
        // via a PrepareItemCraftEvent listener, because the lodestone data must be copied
        // from the compass ingredient at craft-time.
        //
        // We still register a shaped recipe so the server shows the recipe in the
        // recipe book. The static result will be replaced by the listener below.

        ItemStack staticResult = new ItemStack(Material.COMPASS);
        NamespacedKey recipeKey = new NamespacedKey(plugin, "tp_compass");

        ShapedRecipe recipe = new ShapedRecipe(recipeKey, staticResult);

        // Layout:
        //   E . .
        //   . C .   (C = compass with lodestone data, E = echo shard, P = ender pearl)
        //   . . P
        recipe.shape(
                "E  ",
                " C ",
                "  P"
        );

        recipe.setIngredient('E', Material.ECHO_SHARD);
        recipe.setIngredient('C', Material.COMPASS);
        recipe.setIngredient('P', Material.ENDER_PEARL);

        plugin.getServer().addRecipe(recipe);

        // Register the dynamic crafting listener that validates the compass and
        // builds the correct output item.
        plugin.getServer().getPluginManager().registerEvents(
                new CraftListener(plugin, recipeKey),
                plugin
        );
    }
}
